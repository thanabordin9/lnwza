ห// ข้อมูลอ้างอิง Velo API: https://www.wix.com/velo/reference/api-overview/introduction

$w.onReady(function () {

	// เขียนโค้ด Javascript ของคุณที่นี่โดยใช้ Velo framework API

	// พิมพ์ hello world:
	// console.log("Hello world!");

	// เรียกใช้ฟังก์ชันบนองค์ประกอบในหน้าเพจ เช่น:
	// $w("#button1").label = "คลิกที่นี่!";

	// คลิก "Run" หรือดูตัวอย่างเว็บไซต์ของคุณเพื่อให้โค้ดทำงาน

});